#=====================================================================================================#
#                                                IDV Leaners                                          #
#=====================================================================================================#

#            Evidence of the statistical usability of the data generated on whatsapp                  #
#                                           Lucainson RAYMOND                                         #
#=====================================================================================================#

#Loading packages
suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(ggthemes))
suppressPackageStartupMessages(library(ggrepel))
suppressPackageStartupMessages(library(gganimate))
suppressPackageStartupMessages(library(ggimage))
suppressPackageStartupMessages(library(plotly))
suppressPackageStartupMessages(library(RColorBrewer))
suppressPackageStartupMessages(library(factoextra))
suppressPackageStartupMessages(library(scales))
suppressPackageStartupMessages(library(rwhatsapp))
suppressPackageStartupMessages(library(stopwords))
suppressPackageStartupMessages(library(NLP))
suppressPackageStartupMessages(library(tidytext))
suppressPackageStartupMessages(library(tidylo))
suppressPackageStartupMessages(library(stringr))
suppressPackageStartupMessages(library(tm))
suppressPackageStartupMessages(library(topicmodels))
suppressPackageStartupMessages(library(Rmpfr))
suppressPackageStartupMessages(library(tidyr))
suppressPackageStartupMessages(library(widyr))
suppressPackageStartupMessages(library(Metrics))
suppressPackageStartupMessages(library(tseries))
suppressPackageStartupMessages(library(forecast))
suppressPackageStartupMessages(library(lubridate))
suppressPackageStartupMessages(library(corrr))
suppressPackageStartupMessages(library(cluster))
suppressPackageStartupMessages(library(Rtsne))
suppressPackageStartupMessages(library(tsne))
suppressPackageStartupMessages(library(ggraph))
suppressPackageStartupMessages(library(igraph))
suppressPackageStartupMessages(library(wordcloud2))
suppressPackageStartupMessages(library(stringr))
suppressPackageStartupMessages(library(urltools))
suppressPackageStartupMessages(library(Rgraphviz))
suppressPackageStartupMessages(library(visNetwork))
suppressPackageStartupMessages(library(DT))
suppressPackageStartupMessages(library(data.table))


#Reading the dataset
setwd("C:/Users/Lucainson Raymond/Desktop/Casptone")
dataset<-rwa_read("_chat.txt")


#Data overview
dataset%>%
  glimpse()


#Somme basic statistics
#Active users
n_author<-nlevels(dataset$author)

#Total number of messages
n_messages<-length(dataset$text)

#Number of suppressed messages 
msgdeleted="This message was deleted"
msg_you="You deleted this message"
msg_supp1=grep(msgdeleted, dataset$text,value=T)
msg_supp2=grep(msg_you, dataset$text,value=T)
n_supp_mess<-print(length(msg_supp1)+length(msg_supp2))

#Number of emojis
n_emojis<-length((unlist(dataset$emoji_name)))

#Dataframe
df_stat<-data.frame(variable=c("Active users","Total number of messages","Total number of deleted messages","Total number of used emojis"),
                    frequency=c(n_author,n_messages,n_supp_mess,n_emojis))

df_stat %>%
  knitr::kable()%>%
  kable_styling(bootstrap_options = "striped" , full_width = F , position = "center") %>%
  kable_styling(bootstrap_options = "bordered", full_width = F , position ="center") %>%
  column_spec(1,bold = T ) %>%
  column_spec(2,bold =T ,color = "white" , background ="blue")


#Chronological series of messages
dataset%>%
  mutate(day = as.Date.factor(time)) %>%
  mutate(year=year(day))%>%
  filter(!is.na(year))%>%
  count(day) %>%
  ggplot(aes(x = day, y = n),fill="#00AFBB")+
  geom_line(stat = "identity", 
            color= "#00AFBB",size=0.5) +
  ylab("Message frequency per day") +
  xlab("Date") +
  labs(caption = "@Lucainson RAYMOND")+
  theme_classic()+
  theme(
    axis.title.x = element_text(family="Cambria",size=9),
    axis.title.y = element_text(family="Cambria",size=9))



#Statistics of media files shared on the group
#We are going to do some string manipulation in this part using RegeX techniques.
# First, we will extract the traces from the media files by highlighting their patterns in the dataset
image=".*image omitted$"
video=".*video omitted$"
document=".*document omitted$"
contact=".*Contact card omitted$"
audio=".*audio omitted$"
gif=".*GIF omitted$"
sticker=".*sticker omitted$"


#Now using the function grep () which is a function of the "base" package of R, we will extract all of said traces as follows
im=grep(image, dataset$text)
vid=grep(video, dataset$text)
doc=grep(document, dataset$text)
cont=grep(contact, dataset$text)
aud=grep(audio, dataset$text)
gf=grep(gif, dataset$text)
stick=grep(sticker, dataset$text)

#Then we build a vector of data with the frequency of sharing each category of files while formally labeling them for convenience of reading
media<-c(length(im),length(vid),
         length(doc),length(cont),length(aud),
         length(gf),length(stick))

labels<-c("Images","Videos",
          "Documents","Contact card",
          "Audios","GIF","Stickers")

med1<-tibble(media,labels)

fig <- plot_ly(med1, labels = ~labels, values = ~media, type = 'pie',textinfo='label+percent',
               insidetextorientation='radial')

fig 



#Top_20 websites shared on the group
#We are going to do string manipulation again
#We are therefore going to define the regular pattern (Regular expression) of websites with the syntax R. Then, we are going to create two (2) additional columns (url_pattern & url) in the original dataset to link them to the series of exchanges; question of capturing all messages containing a url pattern and extracting it over time

url_pattern <- "http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
dataset$ContentURL <- str_extract(dataset$text, url_pattern)
dataset$url<-suffix_extract(domain(dataset$ContentURL))$host

#Producing a graph with the ggplot2 package
dataset %>%
  mutate(day = as.Date.factor(time)) %>%
  count(url)%>%
  filter(!is.na(url))%>%
  top_n(n = 20, n) %>%
  ggplot(aes(fill=url,x = reorder( url, n), y = n)) +
  geom_bar(stat = "identity",color="black",show.legend = F) +
  scale_fill_manual(values=c("black","#FF5D00","#C8102E", 
                             "#A2A569","#38170B","#BF1B0B",
                             "#8B5B29", "#B9975B", "#EED484",
                             "#6E6259", "#707372", "#ACA39A",
                             "#F1BE48", "#524727", "#76881D",
                             "#9B945F", "#CAC7A7","#3E4827",  
                             "#003D4C", "#006BA6", "#7A99AC",
                             "#7C2529", "#9A3324", "#BE531C",
                             "#999999", "#E69F00", "#56B4E9",
                             "#FFC465", "#66ADE5", "#252A52"))+
  ylab("Frequency") + xlab("") +
  coord_flip() +
  ggtitle("")+
  labs(caption = "@Lucainson RAYMOND")+
  theme(
    axis.title.x = element_text(family="Cambria",size=9),
    axis.title.y = element_text(family="Cambria",size=9))+
  theme_classic()



# Members' activity on the group according to the time of day
d<-dataset %>%
  mutate(hour = hour(time)) %>%
  group_by(hour)%>%
  count(hour) 

d$hour[d$hour=="0"]<-"24h"
d$hour[d$hour=="1"]<-"1h"
d$hour[d$hour=="2"]<-"2h"
d$hour[d$hour=="3"]<-"3h"
d$hour[d$hour=="4"]<-"4h"
d$hour[d$hour=="5"]<-"5h"
d$hour[d$hour=="6"]<-"6h"
d$hour[d$hour=="7"]<-"7h"
d$hour[d$hour=="8"]<-"8h"
d$hour[d$hour=="9"]<-"9h"
d$hour[d$hour=="10"]<-"10h"
d$hour[d$hour=="11"]<-"11h"
d$hour[d$hour=="12"]<-"12h"
d$hour[d$hour=="13"]<-"13h"
d$hour[d$hour=="14"]<-"14h"
d$hour[d$hour=="15"]<-"15h"
d$hour[d$hour=="16"]<-"16h"
d$hour[d$hour=="17"]<-"17h"
d$hour[d$hour=="18"]<-"18h"
d$hour[d$hour=="19"]<-"19h"
d$hour[d$hour=="20"]<-"20h"
d$hour[d$hour=="21"]<-"21h"
d$hour[d$hour=="22"]<-"22h"
d$hour[d$hour=="23"]<-"23h"

d%>%
  ggplot(aes(x = reorder(hour, -n),y=n))+
  geom_bar(stat = "identity", color="black",
           fill="#00AFBB") +
  labs(caption = "@Lucainson RAYMOND")+
  ylab("") + 
  xlab("") +
  theme(plot.title = element_text((hjust=0.5)))+
  theme_classic()


# Members' activity on the group according to the day of the week
#Distribution of messages by day of the week (median number)
dataset %>%
  mutate(x = as.Date(time)) %>%
  select(x)%>%
  group_by(x)%>%
  count()%>%
  mutate(day=weekdays(x))%>%
  mutate(dayx=weekdays(x))%>%
  ungroup()%>%
  select(-x)%>%
  group_by(day)%>%
  summarise(n=round(median(n),0))%>%
  ggplot(aes(x = reorder(day, n), y = n))+
  geom_bar(stat = "identity", color="black",
           fill="#4A9260") +
  labs(caption = "@Lucainson RAYMOND")+
  ylab("") +
  xlab("") +
  theme(plot.title = element_text((hjust=0.5)))+
  theme_classic()


#Bivariate distribution (activity depending on day & time)
dataset$hour<-hour(dataset$time)
dataset$weekdays<-weekdays(dataset$time, abbreviate=F)

df <- dataset %>% 
  group_by(weekdays, hour) %>% 
  summarise(n=n()) %>% 
  rename(`message flow`=n)

#Transforming numbers in hour format
df$hour[df$hour=="0"]<-"24h"
df$hour[df$hour=="1"]<-"1h"
df$hour[df$hour=="2"]<-"2h"
df$hour[df$hour=="3"]<-"3h"
df$hour[df$hour=="4"]<-"4h"
df$hour[df$hour=="5"]<-"5h"
df$hour[df$hour=="6"]<-"6h"
df$hour[df$hour=="7"]<-"7h"
df$hour[df$hour=="8"]<-"8h"
df$hour[df$hour=="9"]<-"9h"
df$hour[df$hour=="10"]<-"10h"
df$hour[df$hour=="11"]<-"11h"
df$hour[df$hour=="12"]<-"12h"
df$hour[df$hour=="13"]<-"13h"
df$hour[df$hour=="14"]<-"14h"
df$hour[df$hour=="15"]<-"15h"
df$hour[df$hour=="16"]<-"16h"
df$hour[df$hour=="17"]<-"17h"
df$hour[df$hour=="18"]<-"18h"
df$hour[df$hour=="19"]<-"19h"
df$hour[df$hour=="20"]<-"20h"
df$hour[df$hour=="21"]<-"21h"
df$hour[df$hour=="22"]<-"22h"
df$hour[df$hour=="23"]<-"23h"

# So we display the data using the graphical grammar from the ggplot2 package
ggplot(df, aes(hour,weekdays)) + 
  geom_tile(aes(fill = `message flow`),
            colour = "white") + 
  geom_text(aes(label=`message flow`),show.legend = F)+
  scale_fill_distiller(palette = "Dark2", 
                       direction = 1) + 
  scale_x_discrete(breaks = df$hour,
                   labels = df$hour) + 
  labs(caption = "@Lucainson RAYMOND")+
  theme(legend.position = "None",
        panel.grid = element_blank()) + 
  coord_equal()+
  theme_bw()


#Top 5 most active according to the day's moment
#By a simple transformation of the "time" column of the original dataset,
#we are going to create the 4 moments, in this case,
#Morning (6h-12h), Afternoon (12h-16h), Evening (Night) & Mid-night (0h-6h)
#Next, we will highlight which of the Users
#are most active during said moments

times=dataset%>%mutate(time=hour(time))
times=times %>% mutate(Moment = case_when(
  time > 6 & time <= 12~ 'Morning',
  time > 12 & time <= 16 ~ 'Afternoon', 
  time > 16 & time <= 21 ~ 'Evening',
  time > 21 & time <= 24 ~ 'Night',
  time > 0 & time <= 6~ 'Mid Night'))

#Next, we run the algorithm by combining the functions in
#several packages of R, including dplyr [count (), filter (), ungroup (), top_n ()],
# then the layers of ggplot2 [ggplot (), geom_bar (), facet_wrap () ...]

times%>%count(author,Moment)%>%
  
  filter(!is.na(author))%>%
  group_by(Moment)%>%filter(!is.na(Moment))%>%
  top_n(n = 5, n) %>%
  ggplot(aes(x=reorder(author,n),y=n,fill=Moment))+
  geom_bar(stat="identity",show.legend = F)+
  facet_wrap(~Moment,ncol=2,scales="free")+
  coord_flip()+
  labs(x="",y="",caption = "@Lucainson RAYMOND")+
  theme(plot.title = element_text((hjust=0)))+
  theme_bw()


#Top most active users of the chat group
getpalette=colorRampPalette(brewer.pal(8,'Dark2'))

dataset%>%
  mutate(day = as.Date.factor(time)) %>%
  count(author)%>%
  filter(!is.na(author))%>%
  top_n(n = 10, n) %>%
  ggplot(aes(x = reorder(author, n), y = n,fill=getpalette(10))) +
  geom_bar(stat = "identity",show.legend = F) +
  ylab("") + 
  xlab("") +
  coord_flip() +
  ggtitle("")+
  labs(caption = "@Lucainson RAYMOND")+
  theme(plot.title = element_text((hjust=0)))+
  theme_bw()



#Top emojis used by top active users
#The top 6 active authors
auth<- dataset %>%
  mutate(day = as.Date.factor(time)) %>%
  count(author)%>%
  filter(!is.na(author))%>%
  arrange(-n)%>%
  top_n(n = 6, n)



dataset %>%
  filter(author %in% auth$author)%>%
  unnest(emoji) %>%
  count(author, emoji, sort = TRUE) %>%
  group_by(author) %>%
  top_n(n = 6, n) %>%
  ggplot(aes(x = reorder(emoji, n), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  coord_flip() +
  facet_wrap(~author, ncol = 2, scales = "free_y")  +
  ggtitle("Most often used emojis")


#Favorite words of the most active developpers
#So now, we are going the transform our text in a corpus
#Let's start by cleaning it, by drop some useless words (stopwords) in french, english and haitian creole (our native language)
to_remove1 <- c(stopwords(kind = "fr"), stopwords(kind="en"),
                "media",
                "omitted","image omitted",
                "ref","manquant","vidéo","remplacé","amp","groupe","group","très",
                "dass","lap","appuyez","intégré","téléphone","numéro","bout","en",
                "schon","me","dak","met","fok","aprs","anne","chiffrés","chiffré","changé","ajouter",
                "mal", "janvier","marchs", "age","send","pages","participants","Participants",
                "android.s.wt","message","document","image","nn","Oserlecrire", "messages",
                "sticker","yo", "de","pa","la","se","ki","c","gen","mw","nou","add","envoyer",
                "ou","li","pou","w","nan","yon","nou","k","a","men","f","ke","retiré",
                "ak","an","sou","tout","menm","si","e","https","ap","tou","paske","settings","dirk","omis",
                "epi","epwi","lan","mpa","non","mwen","ka","we","fè","tt","fe","stp","gon","gen","moun","ion",
                "konn","jan","s'on","anpil","oui","wap","épi","plus","pi","c'est","ion","yon","youn","sa",
                "lot","lè","oubyen","tap","oswa","ds","too","ave","etre","ui","mte","pouw","t","absente","sent",
                "tj","u","jus","jis","ete","w'ap","oserlecrire","g'on","lol",'poun',"infos","sak","fè","supprim",
                "video","deleted","add","changed","pdf","page","phone","number","take","new","waiting",
                "que","qui","pap","pat","nan","toujours","it","i","of",'you',"very","and","donk","san","son",
                "chak","ns","etc","fé","saaa","laa","laaa","mgen","nap","htg","usd","2350","2019",
                "kap",'al',"this","the","supprim","supprimé","for","l","while","may","peut","peuvent","yap","pour","toujou",
                "mar","to","ti","di","wi","ye","2","have","are","dil","masse","fel","map","ok","fon","anh","svp",                    "dim","2500","my","forms.gle","that","siw","d'i", "meme","oserlecrire","2020","25","2","50933976027","o",
                "greg","in","sonw","sak","deux","deuxime","deuxième","faire",'fait','fait faire',"wimax",
                "wifi", "Marchs","allow","allows","Clavens","clavens","formulaire","formulaires",
                "group","Wilbens","wilbens","association","Association","atwood","salutations","left","Marchs","Administration","administration",
                "added","untitled","annuel","collects", "p","io","ui","uii","uiii","pral","509","poum","poun",
                "konsa","bn","GIF","gif","audio","Audio","bout","en","chiffrement","ann","hein","via","one","two","using","link","invite","joined",
                "mage","Omitted","video","Video","dirk","2400")



#Let's clean up the text again, removing other non-informative "regex" (url, numbers, useless white spaces, punctuation ...)
whatsapp <- data.frame(text=dataset$text)
whatsapp$text <- as.character(whatsapp$text)
whatsapp$text <- gsub('\\p{So}|\\p{Cn}', '', whatsapp$text, perl = TRUE)
whatsapp$text <- gsub('http\\S+\\s*', '', whatsapp$text)
whatsapp$text <- gsub("[[:digit:]]", '', whatsapp$text)
whatsapp$text <- gsub('\\b+RT', '', whatsapp$text)
whatsapp$text <- gsub('#\\S+', '', whatsapp$text)
whatsapp$text <- gsub('@\\S+', '', whatsapp$text)
whatsapp$text <- gsub("+509\\S+", '', whatsapp$text)
whatsapp$text <- gsub('[[:cntrl:]]', '', whatsapp$text)
whatsapp$text <- gsub("\\d", '', whatsapp$text)
whatsapp$text <- gsub("[:graph:]]", '', whatsapp$text)
whatsapp$text <- gsub("<(.+)>", '', whatsapp$text)
whatsapp$text <- gsub('<p{So}|>p{Cn}', '', whatsapp$text, perl = TRUE)
whatsapp$text <- gsub("\uFFFD", "", whatsapp$text, fixed=TRUE)

# Specification of a function to lower case all tokens (1-gram) of the text
tryTolower <- function(x){
  # return NA when there is an error
  y=NA
  # tryCatch error
  try_error= tryCatch(tolower(x),error=function(e) e)
  if (!inherits(try_error, 'error'))
    y=tolower(x)
  
  return(y)
}

#Cleaning (continued)
custom.stopwords <- c(stopwords('english'),to_remove1)
clean.corpus <- function(corpus) {
  corpus <- tm_map(corpus,
                   content_transformer(tryTolower))
  corpus <- tm_map(corpus,removeWords,
                   custom.stopwords)
  corpus<-tm_map(corpus,removePunctuation)
  corpus <- tm_map(corpus,stripWhitespace)
  corpus <- tm_map(corpus,removeNumbers)
  return(corpus)
}
corpus <- Corpus(VectorSource(whatsapp$text))
corpus <- clean.corpus(corpus)
corpus<-tm_map(corpus, function(x) iconv(x, "latin1", "ASCII", sub=""))



#Conversion now of the corpus into a Document-Term-Matrix object
dtm <- DocumentTermMatrix(corpus)

wh_td <- tidy(dtm)


#Wordcloud
wh_words <- wh_td %>%
  count(term,sort=TRUE) %>%
  filter(n >= 10)

wordcloud2(data=wh_words,size=0.8,fontFamily = "Cambria",
           color = "random-light",backgroundColor = "black")


#Bag-of-word barplot
data.frame(text = sapply(corpus, as.character), stringsAsFactors = FALSE) %>% 
  unnest_tokens(output = ngram, input = text, token="ngrams",n=1) %>% 
  count(ngram, sort = TRUE) %>% 
  arrange(desc(n))%>%
  filter(!is.na(ngram))%>%
  slice(1:20) %>% 
  ggplot(aes(fct_reorder(ngram, n), n)) + 
  geom_col(aes(fill=n), show.legend = FALSE, width = .1) +
  geom_point(aes(color=n), show.legend = FALSE, size = 3)+
  coord_flip()+
  theme_minimal() +
  labs(x="Words", y="Frequency",title = "Bag-of-Words analysis of the corpus",
       caption = "@Lucainson RAYMOND")+
  scale_fill_gradient(low="#2b83ba",high="darkred") +
  scale_color_gradient(low="#2b83ba",high="#d7191c") +
  theme_bw()


# Bi-gram barplot
data.frame(text = sapply(corpus, as.character), stringsAsFactors = FALSE) %>% 
  unnest_tokens(output = ngram, input = text, token="ngrams",n=2) %>% 
  count(ngram, sort = TRUE) %>% 
  arrange(desc(n))%>%
  filter(!is.na(ngram))%>%
  slice(1:20) %>% 
  ggplot(aes(fct_reorder(ngram, n), n)) + 
  geom_col(aes(fill=n), show.legend = FALSE, width = .1) +
  geom_point(aes(color=n), show.legend = FALSE, size = 3)+
  coord_flip()+
  theme_minimal() +
  labs(x="Bigram", y="Frequency",title = "Bigram analysis of the corpus",
       caption = "@Lucainson RAYMOND")+
  scale_fill_gradient(low="#2b83ba",high="darkred") +
  scale_color_gradient(low="#2b83ba",high="#d7191c") +
  theme_bw()


#Tri-gram barplot
data.frame(text = sapply(corpus, as.character), stringsAsFactors = FALSE) %>% 
  unnest_tokens(output = ngram, input = text, token="ngrams",n=3) %>% 
  count(ngram, sort = TRUE) %>% 
  arrange(desc(n))%>%
  filter(!is.na(ngram))%>%
  slice(1:20) %>% 
  ggplot(aes(fct_reorder(ngram, n), n)) + 
  geom_col(aes(fill=n), show.legend = FALSE, width = .1) +
  geom_point(aes(color=n), show.legend = FALSE, size = 3)+
  coord_flip()+
  theme_minimal() +
  labs(x="Trigram", y="Frequency",title = "Trigram analysis of the corpus",
       caption = "@Lucainson RAYMOND")+
  scale_fill_gradient(low="#2b83ba",high="darkred") +
  scale_color_gradient(low="#2b83ba",high="#d7191c") +
  theme_bw()



#Lexical diversity of top users
dataset %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(!word %in% to_remove1) %>%
  group_by(author) %>%
  filter(!is.na(author))%>%
  summarise(lex_diversity = n_distinct(word)) %>%
  arrange(desc(lex_diversity)) %>%
  top_n(n = 10, lex_diversity)%>%
  ggplot(aes(x = reorder(author, lex_diversity),
             y = lex_diversity,
             fill = author)) +
  geom_col(show.legend = FALSE) +
  scale_y_continuous(expand = (mult = c(0, 0, 0, 500))) +
  #geom_text(aes(label = scales::comma(lex_diversity)), hjust = -0.1) +
  ylab("") +
  xlab("") +
  labs(title="Richness of user's vocabulary",caption="@Lucainson RAYMOND") +
  theme(plot.title = element_text((hjust=0.5)))+
  coord_flip()+
  theme_classic()



#Predilection words of top users (Unweighted frequency)
auth<- dataset %>%
  mutate(day = as.Date.factor(time)) %>%
  count(author)%>%
  filter(!is.na(author))%>%
  arrange(-n)%>%
  top_n(n = 6, n)

dataset %>%
  unnest_tokens(input = text,
                output = word) %>%
  filter(!word %in% to_remove1) %>%
  mutate(word = gsub(".com", "", word)) %>%
  mutate(word = gsub("^gag", "9gag", word)) %>%
  mutate(word = gsub("[[:digit:]]", "", word))%>%
  filter(!word %in% "")%>%
  count(author, word, sort = TRUE) %>%
  group_by(author) %>%
  top_n(n = 5, n) %>%
  filter(!is.na(author))%>%
  filter(author %in% auth$author)%>%
  ggplot(aes(x = reorder_within(word, n, author), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  labs(caption = "@Lucainson RAYMOND")+
  coord_flip() + 
  facet_wrap(~author, ncol = 2, scales = "free_y") +
  scale_x_reordered() +
  ggtitle("")+
  theme_bw()






#Predilection words of top users (Model-based approach: tf-idf)

dataset %>%
  unnest_tokens(input = text,
                output = word) %>%
  select(word, author) %>%
  filter(!word %in% to_remove1) %>%
  mutate(word = gsub(".com", "", word)) %>%
  mutate(word = gsub("^gag", "9gag", word)) %>%
  mutate(word = gsub("[[:digit:]]", "", word))%>%
  filter(!word %in% "")%>%
  count(author, word, sort = TRUE) %>%
  filter(!is.na(author))%>%
  bind_tf_idf(term = word, document = author, n = n) %>%
  group_by(author) %>%
  filter(author %in% auth$author) %>%
  top_n(n = 5, tf_idf) %>%
  ggplot(aes(x = reorder_within(word, n, author), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  labs(caption = "@Lucainson RAYMOND")+
  coord_flip() +
  facet_wrap(~author, ncol = 2, scales = "free_y") +
  scale_x_reordered() +
  ggtitle("Model-based approach: tf-idf")+
  theme(plot.title = element_text((hjust=0.5)))+
  theme_bw()





#Predilection words of top users (Model-based approach: Weighted log odds ratio)

dataset %>%
  unnest_tokens(input = text,
                output = word) %>%
  select(word, author) %>%
  filter(!word %in% to_remove1) %>%
  mutate(word = gsub(".com", "", word)) %>%
  mutate(word = gsub("^gag", "9gag", word)) %>%
  mutate(word = gsub("[[:digit:]]", "", word))%>%
  filter(!word %in% "")%>%
  count(author, word, sort = TRUE) %>%
  filter(!is.na(author))%>%
  bind_log_odds(feature = word, set = author, n = n) %>%
  group_by(author) %>%
  filter(author %in% auth$author) %>%
  top_n(n = 5, log_odds_weighted) %>%
  ggplot(aes(x = reorder_within(word, n, author), y = n, fill = author)) +
  geom_col(show.legend = FALSE) +
  ylab("") +
  xlab("") +
  labs(caption = "@Lucainson RAYMOND")+
  coord_flip() +
  facet_wrap(~author, ncol = 2, scales = "free_y") +
  scale_x_reordered() +
  ggtitle("Model-based approach: Weighted log odds ratio")+
  theme(plot.title = element_text((hjust=0.5)))+
  theme_bw()




#Word Network Plot

#Conversion of the corpus into a Term-Document-Matrix object
tdm<-TermDocumentMatrix(corpus)
print(tdm)


getConditionedDataFrame <- function(Corpus) {
  # calculate the frequency of words and sort it by frequency
  word.freq <- sort(rowSums(as.matrix(tdm)), decreasing = T)
  word.freq <- subset(word.freq, word.freq >=1)
  df <- data.frame(term = names(word.freq), freq = word.freq)
  return(df)
}


what.df <- getConditionedDataFrame(Corpus)
what.df.t <- what.df[,-2]


corpus1<-corpus

bigr <- data.frame(text = sapply(corpus1, as.character), stringsAsFactors = FALSE) %>% 
  unnest_tokens(bigram, text, token = "ngrams", n = 2)

two_word <- bigr %>% count(bigram, sort = TRUE)%>%
  drop_na()

bigrams_separated <- two_word %>%
  separate(bigram, c("word1", "word2"), sep = " ")

bigram_graph <- head(bigrams_separated %>% 
                       arrange(desc(n)),30) %>% 
  graph_from_data_frame()

#bigram_graph

set.seed(1996)
ggraph(bigram_graph, layout = "stress") +
  geom_edge_link() +
  geom_node_point() +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1)

a <- grid::arrow(type = "closed", length = unit(.08, "inches"))
ggraph(bigram_graph, layout = "fr") +
  geom_edge_link(aes(edge_alpha = n), show.legend = FALSE,
                 arrow = a, end_cap = circle(.08, 'inches')) +
  geom_node_point(color = "lightblue", size = 4) +
  geom_node_text(aes(label = name), vjust = 1, hjust = 0.5, size=5) +
  theme_void()


#Word Correlation Plot

corpus2<-corpus
raym <- data.frame(text = sapply(corpus2, as.character), stringsAsFactors = FALSE)
raym$what_nbr <- 1:nrow(raym)
what_word <- raym %>% unnest_tokens(word, text)
what_word1 <- raym %>% unnest_tokens(word, text)%>%
  group_by(word)%>%
  count(sort=T)


what_word_correl <- what_word %>% 
  group_by(word) %>% 
  filter(n() >= 15) %>% 
  pairwise_cor(word, what_nbr, sort = TRUE, upper = FALSE)


set.seed(1996)
what_word_correl %>%
  filter(correlation > 0.3) %>%
  graph_from_data_frame() %>%
  ggraph(layout = "fr") +
  geom_edge_link(aes(edge_alpha = correlation, edge_width = correlation), edge_colour = "blue") +
  geom_node_point(size = 5) +
  geom_node_text(aes(label = name), repel = TRUE,
                 point.padding = unit(0.2, "lines"))+
  theme_void()



#Word Association with “data”

associations <- findAssocs(tdm, "data", 0.18)
associations <- as.data.frame(associations)
associations$terms <- row.names(associations)
associations$terms <- factor(associations$terms,
                             levels=associations$terms)
ggplot(associations,aes(y=terms)) +
  geom_point(aes(x=data),data=associations,size=3) +
  theme_gdocs() +
  geom_text(aes(x=data,label=data),
            colour="darkblue",hjust=-0.25,size=4) +
  theme(text=element_text(size=15),
        axis.title.y=element_blank())


#Word Association with “haiti”

associations <- findAssocs(tdm, "haiti", 0.12)
associations <- as.data.frame(associations)
associations$terms <- row.names(associations)
associations$terms <- factor(associations$terms,
                             levels=associations$terms)
ggplot(associations,aes(y=terms)) +
  geom_point(aes(x=haiti),haiti=associations,size=3) +
  theme_gdocs() +
  geom_text(aes(x=haiti,label=haiti),
            colour="darkblue",hjust=-0.25,size=4) +
  theme(text=element_text(size=15),
        axis.title.y=element_blank())


#Word Association with “people”

associations <- findAssocs(tdm, "people", 0.25)
associations <- as.data.frame(associations)
associations$terms <- row.names(associations)
associations$terms <- factor(associations$terms,
                             levels=associations$terms)
ggplot(associations,aes(y=terms)) +
  geom_point(aes(x=people),people=associations,size=3) +
  theme_gdocs() +
  geom_text(aes(x=people,label=people),
            colour="darkblue",hjust=-0.25,size=4) +
  theme(text=element_text(size=15),
        axis.title.y=element_blank())




#Detection of Zipf's law in user exchanges

terms <- wh_td %>%
  count(term,sort=T)
print(terms)

terms$var <- 1
totalterms <- terms %>%
  group_by(var) %>%
  summarize(total=sum(n))
terms_total <- left_join(terms,totalterms)

print(terms_total)

ggplot(terms_total,aes(n/total)) +
  geom_histogram(fill="green",color="darkgreen",show.legend=FALSE) +
  xlim(NA,0.010) +
  ggtitle("Frequency distribution of terms in exchanges")


freq_by_rank <- terms_total %>%
  mutate(rank=row_number()) %>%
  mutate(tfreq=n/total)
print(freq_by_rank)

p <- ggplot(freq_by_rank,aes(x=rank,y=tfreq)) +
  geom_line(size=1,col="red",alpha=.8,show.legend=FALSE) +
  scale_y_log10() +
  ggtitle("Visualization of Zipf's law in message flows")
print(p)




#Word Embedding
#We use the TF-IDF metric to section the corpus into clusters
dtm_tfidf <-DocumentTermMatrix(corpus,control = list(weighting = function(x) weightTfIdf(x, normalize = FALSE)))
str(dtm_tfidf)
inspect(dtm_tfidf)

dtm_tfidf2<-removeSparseTerms(dtm_tfidf,sparse=0.994)
print(dtm_tfidf2)

#Conversion of dtm object to matrix
m2 <- as.matrix(dtm_tfidf2)


#t-distributed Stochastic Neighbor Embedding (t-SNE)
#Training of the model 
tsne_out <- Rtsne(m2,dims=2,check_duplicates=F,perplexity=30,theta=0.5,pca=T,verbose=T,max_iter = 500, num_threads = 0)

m <- as.matrix(tdm)
plot(tsne_out$Y,t="n",main="Two-dimensional reduction of the space of TF-IDF vectors using t-SNE",cex.main=1)
text(tsne_out$Y,labels=rownames(m),cex=0.25)

#The t-SNE coordinates will then be adjusted to CLARA (clustering for Large Applications), which will result from the extraction of 6 clusters
X1 <- tsne_out$Y[,1]
X2 <- tsne_out$Y[,2]
# clara clustering
df <- data.frame(X1,X2)

clara.res <- clara(df,6,samples=40,pamLike=TRUE)
fviz_cluster(clara.res,
             palette = c("darkred","darkgreen","darkblue","purple","black","yellow"), # color palette
             ellipse.type = "t", # Ellipse de Concentration
             geom = "point", pointsize = 0.5,title="Cluster plot of t-SNE coordinates TF-IDF",
             ggtheme = theme_classic())



#Word importance with the bind_tf_idf() function
dd <- cbind(df,cluster=clara.res$cluster)
dd$document <- as.numeric(rownames(dd))
dd$document <- as.character(dd$document)
dd$cluster <- as.factor(dd$cluster)
final <- left_join(wh_td,dd)
final2 <- final %>%
  group_by(cluster) %>%
  count(cluster,term,sort=TRUE) %>%
  ungroup()
totals <- final2 %>%
  group_by(cluster) %>%
  summarize(total=sum(n))
cluster_words <- left_join(final2,totals)
print(cluster_words)


#Distribution of term frequencies in document clusters
ggplot(cluster_words,aes(n/total,fill=cluster)) +
  geom_histogram(show.legend=FALSE) +
  facet_wrap(~ cluster,ncol=2,scales="free_y") +
  ggtitle("Distribution of term frequencies in document clusters")


cluster_words <- cluster_words %>%
  bind_tf_idf(term,cluster,n)
print(cluster_words)


# The idf & the tf-idf are zero (0) for common words appearing in all clusters
cluster_words %>%
  select(-total) %>%
  arrange(desc(tf_idf)) %>%
  mutate(term=factor(term,levels=rev(unique(term)))) %>%
  group_by(cluster) %>%
  top_n(5) %>%
  ungroup %>%
  ggplot(aes(term,tf_idf,fill=cluster)) +
  geom_col(show.legend=FALSE) +
  labs(x=NULL,y="tf-idf") +
  facet_wrap(~ cluster,ncol=2,scales="free") +
  coord_flip() +
  ggtitle("Strongest tf-idf of words in each document cluster")




#Topic modeling
#a kind of average to judge log-liklihood by
harmonicMean <- function(logLikelihoods, precision = 2000L) {
  llMed <- median(logLikelihoods)
  as.double(llMed - log(mean(exp(-mpfr(logLikelihoods,
                                       prec = precision) + llMed))))
}

corpus_x<-tm_map(corpus, function(x) iconv(x, "latin1", "ASCII", sub=""))
dtm<-DocumentTermMatrix(corpus_x)
dtm<-removeSparseTerms(dtm,sparse=0.994)

#TDM/DTM for topic modeling 
#remove empty values from DTM and original dataframe copy
rowTotals <- apply(dtm , 1, sum) 
dtm<- dtm[rowTotals> 0, ]
dataset <- dataset[rowTotals> 0,]


#run LDA model n times
seqk <- seq(2, 15, 1)
burnin <- 500
iter <- 500
keep <- 50

fitted_many <- lapply(seqk, function(k) LDA(dtm, k = k, method = "Gibbs",
                                            control = list(burnin = burnin, iter = iter, keep = keep)))

#Extract logliks from each topic
logLiks_many <- lapply(fitted_many, function(L)  L@logLiks[-c(1:(burnin/keep))])

#Compute harmonic means
hm_many <- sapply(logLiks_many, function(h) harmonicMean(h))


#Create model with the GIBBS sampling method
lda.mod <- LDA(dtm, seqk[which.max(hm_many)], method = "Gibbs", control = list(iter=2000))

#Gather topics
topics <- topics(lda.mod, 1)

#HEATMAT TOPIC MODELING

toptermsPerTopic <- terms(lda.mod, 10)
topicNames <- apply(toptermsPerTopic, 2, paste, collapse=" ")


tmResult <- posterior(lda.mod)
theta <- tmResult$topics

countsOfPrimaryTopics <- rep(0,seqk[which.max(hm_many)])
names(countsOfPrimaryTopics) <- topicNames
for (i in 1:nDocs(dtm)) {
  topicsPerDoc <- theta[i, ] # select topic distribution for document i
  # get first element position from ordered list
  primaryTopic <- order(topicsPerDoc, decreasing = TRUE)[1] 
  countsOfPrimaryTopics[primaryTopic] <- countsOfPrimaryTopics[primaryTopic] + 1
}

#Topic proportions over time
#In a last step, we provide a distant view on the topics in the data over time. 
#For this, we aggregate mean topic proportions per month of all SOTU speeches. 
#These aggregated topic proportions can then be visualized as a bar plot.

#Append month information for aggregation
dataset$month <- substr(dataset$time, 0, 7)

#Get mean topic proportions per month
topic_proportion_per_month <- aggregate(theta, by = list(month = dataset$month), mean)

#Set topic names to aggregated columns
colnames(topic_proportion_per_month)[2:(seqk[which.max(hm_many)]+1)] <- topicNames

#Reshape data frame
suppressPackageStartupMessages(library(reshape))
vizDataFrame <- melt(topic_proportion_per_month, id.vars = "month")%>%
  dplyr::rename(topic=variable)
vizDataFrame$value<-round(vizDataFrame$value,4)

#Plotting topic proportions per month as bar plot
g<-ggplot(vizDataFrame, aes(x=month, y=value, fill=topic)) + 
  geom_bar(stat = "identity") + ylab("proportion") + 
  scale_fill_viridis(discrete = T,option="B")+ 
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

ggplotly(g)  





#Sentiment analysis with the tidytext package
#Tidy format
pol_tidy<-tidy(dtm)
pol_tidy[7907:7920,]

colnames(pol_tidy)<-c('line_number','word','count')
pol_tidy$line_number<-as.numeric(pol_tidy$line_number)


# Polarity of feelings with the bing lexicon
bing<-get_sentiments("bing")
pol_sentiment<-inner_join(pol_tidy,bing)

pol_sentiment<-count(pol_sentiment,sentiment,
                     index=line_number)

pol_sentiment<-spread(pol_sentiment,sentiment,n, fill=0)
pol_sentiment[15:20,]

pol_sentiment$polarity<-pol_sentiment$positive-pol_sentiment$negative
pol_sentiment$pol<-ifelse(pol_sentiment$polarity>=0,
                          "pos", "neg")



#Plot with ggplot2
ggplot(pol_sentiment, aes(x=index, y=polarity,
                          fill=pol)) +
  geom_bar(stat="identity", position="identity",width=
             15)+theme_gdocs()




#Application of the GAM (General Additive Modeling) algorithm to evaluate 
#the trajectory of polarity over time

#smoothing
pol_smooth<- ggplot(pol_sentiment, aes(index, polarity))
print(pol_smooth + stat_smooth()+theme_gdocs())


#Emotions released in the discussions
data=pol_tidy%>%
  inner_join(get_sentiments("nrc"),by="word")
data[c(1:10),]


sentimentcount=data%>%
  group_by(sentiment)%>%
  filter(sentiment %in% c("joy","anger",
                          "disgust","fear","sadness",
                          "surprise","anticipation",
                          "trust"))%>%
  count()%>%arrange(desc(n))
ggplot(sentimentcount, aes(x=reorder(sentiment,n), 
                           y=n,fill=sentiment)) +
  geom_bar(stat="identity", width=1, color="white") +
  coord_flip()+theme_bw()+labs(x='Classified emotions',y='Use',title = "Distribution of emotions")



#Emotions according to the time of day
data1=dataset%>%unnest_tokens(word,text)
textsentiment1=data1%>%
  inner_join(get_sentiments("nrc"))

times=textsentiment1%>%mutate(time=hour(time))
times=times %>% mutate(Moment = case_when(
  time > 6 & time <= 12~ 'Morning',
  time > 12 & time <= 16 ~ 'Afternoon', 
  time > 16 & time <= 21 ~ 'Evening',
  time > 21 & time <= 24 ~ 'Night',
  time > 0 & time <= 6~ 'Mid Night'))
times%>%count(sentiment,Moment)%>%
  filter(sentiment %in% c("joy","anger","disgust","fear",
                          "sadness","surprise","anticipation","trust"))%>%
  group_by(Moment)%>%filter(!is.na(Moment))%>%ungroup()%>%
  ggplot(aes(x=reorder(sentiment,n),y=n,fill=Moment))+
  geom_bar(stat="identity")+facet_wrap(~Moment,ncol=2,scales="free")+
  coord_flip()+
  labs(x="Emotions",y="Count",title = "Distribution of emotions by time of day")


#Network Analysis for the chat group
nodes <- dataset %>%
  dplyr::group_by(id = author) %>%
  summarise() %>%
  mutate(label = id)

edges <- dataset %>%
  select(author, text) %>%
  dplyr::rename(from = author) %>%
  mutate(to = str_extract(text, paste(unique(dataset$author), collapse = "|"))) %>%
  select(from, to) %>%
  na.omit() %>%
  dplyr::group_by(from,to) %>%
  summarise(value = n())

visNetwork(nodes, edges, main="User network analysis", 
           submain = "Based on tag", font="white") %>% 
  visOptions(highlightNearest = TRUE)%>% 
  visEdges(arrows = 'from',font='white')%>%
  visInteraction(navigationButtons = TRUE,tooltipStyle = 'position: fixed;visibility:hidden;padding: 5px;white-space: nowrap;
 font-family: cursive;font-size:18px;font-color:purple;background-color: red')%>%
  visNodes(font= '14px arial white')


#Forecasting
time_series<-dataset %>%
  mutate(day = as.Date.factor(time)) %>%
  count(day)

#Print the first 10 values
head(time_series,10)


#Training the bagged model by a boostrap process
set.seed(1996)
sarima_model <- baggedModel(time_series$n,bootstrapped_series = bld.mbb.bootstrap(time_series$n, 50),fn = auto.arima,trace=F)
arima_fitted <- round(as.vector(sarima_model$fitted),0)


time<-seq_along(time_series$n)
sarimaFitted <- as.data.frame(cbind(time,arima_fitted, time_series$n))


plot_ly(sarimaFitted, x = ~time) %>%
  add_lines(y = ~time_series$n, mode = "lines", text=~time_series$day, name = "real data") %>%
  add_lines(y = ~arima_fitted, mode = "lines", text=~time_series$day, name = "model output") %>%
  layout(title = "ARIMA bagged model",
         xaxis=list(autorange=TRUE),
         yaxis=list(title="",autorange=TRUE))


fcast <- forecast(sarima_model,h=10)
fcast1<-as_tibble(fcast)
fcast1$`Point Forecast`<-round(fcast1$`Point Forecast`,0)
head(fcast1,10)

#Plot
plot(fcast)


sarima_tab<- as_tibble(cbind(arima_fitted, time_series$n))
sarima_tab<-cbind(sarima_tab,as.Date(time_series$day))%>%
  as_tibble()%>%
  rename(Day=`as.Date(time_series$day)`)%>%
  rename(real_data=V2)

#Arrange the tibble data by decreasing order
sarima_tab<-sarima_tab[order(sarima_tab$Day,decreasing = T),]

head(sarima_tab,10)




